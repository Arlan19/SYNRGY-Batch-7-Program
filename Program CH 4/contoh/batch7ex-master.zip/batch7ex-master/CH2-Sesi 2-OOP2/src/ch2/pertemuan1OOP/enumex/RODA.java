package ch2.pertemuan1OOP.enumex;

public enum RODA {
    EMPAT,ENAM
}
