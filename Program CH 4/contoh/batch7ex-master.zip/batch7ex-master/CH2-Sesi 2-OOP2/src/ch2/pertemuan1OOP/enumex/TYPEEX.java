package ch2.pertemuan1OOP.enumex;

public enum TYPEEX {
    AVANZA,SEDAN
}
