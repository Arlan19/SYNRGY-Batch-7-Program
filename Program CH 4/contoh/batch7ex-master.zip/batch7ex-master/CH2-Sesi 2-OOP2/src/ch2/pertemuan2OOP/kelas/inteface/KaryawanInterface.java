package ch2.pertemuan2OOP.kelas.inteface;

public interface KaryawanInterface  {
    // class superclass : induk

    public  void save(String nama);

    public  void update(String nama);

    public  void list(String nama);
}
