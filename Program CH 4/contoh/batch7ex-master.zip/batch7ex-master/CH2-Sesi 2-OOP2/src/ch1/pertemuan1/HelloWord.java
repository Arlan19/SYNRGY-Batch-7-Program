package ch1.pertemuan1;

import ch2.pertemuan1OOP.kelas.Mobil;
import ch2.pertemuan2OOP.kelas.inheritance.StaticAndFInal;

import java.util.Date;

public class HelloWord {



    public static void main(String[] args) {
        System.out.println("Hello Word");
        String getValue =  StaticAndFInal.URLUPLOADFILE;

        Double getValuePhi =  StaticAndFInal.nilai;

    }
}
