package com.example.batch7;

import lombok.Data;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Batch7Application {

	public static void main(String[] args) {
		SpringApplication.run(Batch7Application.class, args);
	}

}
