package ch1.pertemuan4;

public class MathEx {

    public static void main(String[] args) {
        System.out.println(Math.max(10,20));
        System.out.println(Math.min(10,20));
    }
}
