package ch1.pertemuan2;

public class CompileEror {
    public static void main(String[] args) {
       Integer qty = null;
       int parsingQty = qty;
    }
}
