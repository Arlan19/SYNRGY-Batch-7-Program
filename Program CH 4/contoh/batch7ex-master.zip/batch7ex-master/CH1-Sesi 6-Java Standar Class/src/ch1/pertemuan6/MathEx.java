package ch1.pertemuan6;

public class MathEx {
    public static void main(String[] args) {
        System.out.println(Math.max(12,45));
    }
}
