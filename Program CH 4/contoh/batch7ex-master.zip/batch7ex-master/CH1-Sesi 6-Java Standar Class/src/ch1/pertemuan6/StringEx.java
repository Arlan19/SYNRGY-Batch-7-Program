package ch1.pertemuan6;

public class StringEx {
    public static void main(String[] args) {
        String varA= "makan".concat("nasi").concat("direstoran").concat("padang");
        String varB= "makan"+ "nasi";
        System.out.println(varA);
        System.out.println(varB);

    }
}
