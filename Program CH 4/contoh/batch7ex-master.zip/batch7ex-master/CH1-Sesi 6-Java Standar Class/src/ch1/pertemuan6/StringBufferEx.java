package ch1.pertemuan6;

public class StringBufferEx {
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("");
        sb.append("belajar");
        sb.append("java");
        sb.append("di binar");

        System.out.println(sb.toString());
    }

}
