package com.example.demo.skemployee.dto;

import lombok.Data;

import java.util.List;

@Data
public class ProvinsiResponse {
    private List<Provinsi> provinsi;
}
