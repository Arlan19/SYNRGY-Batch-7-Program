package com.example.demo.skemployee.service.impl;

import com.example.demo.skemployee.entity.Employee;
import org.springframework.stereotype.Service;

import java.util.Map;


@Service
public class EmployeeTrainingService implements com.example.demo.skemployee.service.EmployeeTrainingService {
    @Override
    public Map save(Employee request) {
        return null;
    }

    @Override
    public Map edit(Employee request) {
        return null;
    }

    @Override
    public Map delete(Employee request) {
        return null;
    }

    @Override
    public Map list() {
        return null;
    }
}
