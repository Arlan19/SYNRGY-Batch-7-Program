package com.example.demo.skemployee.dto;

import lombok.Data;

@Data
public class Provinsi {
    private int id;
    private String nama;
}