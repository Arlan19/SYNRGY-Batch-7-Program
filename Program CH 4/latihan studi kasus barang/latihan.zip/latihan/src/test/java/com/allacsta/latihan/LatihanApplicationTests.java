package com.allacsta.latihan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LatihanApplicationTests {

	@Test
	void contextLoads() {
	}

}
