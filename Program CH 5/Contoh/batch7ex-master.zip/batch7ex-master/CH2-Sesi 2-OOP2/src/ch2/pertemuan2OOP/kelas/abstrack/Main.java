package ch2.pertemuan2OOP.kelas.abstrack;public class Main {
}
