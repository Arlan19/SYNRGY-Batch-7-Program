package ch2.pertemuan2OOP.kelas.enumex;

public enum TYPEEX {
    AVANZA,SEDAN
}
