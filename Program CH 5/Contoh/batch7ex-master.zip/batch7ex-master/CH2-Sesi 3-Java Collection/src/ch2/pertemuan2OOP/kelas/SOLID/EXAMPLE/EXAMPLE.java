package ch2.pertemuan2OOP.kelas.SOLID.EXAMPLE;

public class EXAMPLE {
    public static void main(String[] args) {
        String nama1= "angga";
        String nama2= "angga";
        String nama3= "angga";
        String nama4= "angga";


    }

    public void cetakAngka(){
        cetakAngka2();
    }


    public void cetakAngka1(){
        cetakAngka2();
    }

    public void cetakAngka2(){
        System.out.println("cetak angka");
    }
}
