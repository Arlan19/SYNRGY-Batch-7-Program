package ch1.pertemuan1;

import java.util.Date;

public class HelloWord {



    public static void main(String[] args) {
        System.out.println("Hello Word");
    }
}
