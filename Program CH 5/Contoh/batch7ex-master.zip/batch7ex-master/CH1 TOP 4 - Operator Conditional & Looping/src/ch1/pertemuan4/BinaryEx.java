package ch1.pertemuan4;

public class BinaryEx {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        int c = a + b;
        System.out.println(a+b);
        System.out.println(c);
        System.out.println(hitungAdd(1,2));
    }

    public static  int hitungAdd(int a, int b){
        return  a+b;
    }
}
