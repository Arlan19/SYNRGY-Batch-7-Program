package com.example.batch7.ch3.junit;

public class MathService {
    public int add(int a, int b) {
        return a + b;
    }
}
