package ch1.pertemuan5;

public class SampleEx {
    public static void main(String[] args) {
        System.out.println("    *    ");
        System.out.println("   * *   ");
        System.out.println("  * * *    ");

//        for(
//
//                for()
//        )
    }

}
