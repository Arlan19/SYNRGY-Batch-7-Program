package ch1.pertemuan4;

public class Main {
    /* topik
    DONE Array
    DOEN Math, Equality dan Boolean operators
    DONE Expression= bagian dari starment, Statement = satu baris kode program  dan Block= kumpulan staement
    DONE If else dan Ternary operation
    DONE Switch Case
    For
    While
    Do-while
     */
}
