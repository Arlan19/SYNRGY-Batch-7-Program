package ch2.pertemuan2OOP.kelas.enumex;

public class Mobil {
    private  RODA roda;
    private  TYPEEX type;
    private  int kecepatan ;

}
