package ch1.pertemuan1;

import ch2.pertemuan1OOP.kelas.Mobil;

import java.util.Date;

public class HelloWord {



    public static void main(String[] args) {
        System.out.println("Hello Word");
    }
}
