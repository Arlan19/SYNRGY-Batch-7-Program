package ch1.pertemuan4;

public class DoWhileEx {
    public static void main(String[] args) {
       int var = 10;
       do{
           System.out.println("value ="+var);
           var--;
       }while (var>20);
    }
}
