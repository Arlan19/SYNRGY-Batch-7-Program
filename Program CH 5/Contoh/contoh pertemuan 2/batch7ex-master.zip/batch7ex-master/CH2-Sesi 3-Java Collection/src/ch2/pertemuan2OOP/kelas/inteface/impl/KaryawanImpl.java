package ch2.pertemuan2OOP.kelas.inteface.impl;

import ch2.pertemuan2OOP.kelas.inteface.KaryawanInterface;

public class KaryawanImpl  implements KaryawanInterface {
    // class subclass : induk
    /*
    membuat logi c-> save kek databse
     */

    String name="3434";

    @Override
    public void save(String nama) {
        // empty
    }

    @Override
    public void update(String nama) {

    }

    @Override
    public void list(String nama) {

    }

}
