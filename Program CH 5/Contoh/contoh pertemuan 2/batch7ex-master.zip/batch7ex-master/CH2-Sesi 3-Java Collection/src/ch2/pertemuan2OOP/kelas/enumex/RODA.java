package ch2.pertemuan2OOP.kelas.enumex;

public enum RODA {
    EMPAT(40),ENAM(30);

    RODA(int i) {

    }
}
