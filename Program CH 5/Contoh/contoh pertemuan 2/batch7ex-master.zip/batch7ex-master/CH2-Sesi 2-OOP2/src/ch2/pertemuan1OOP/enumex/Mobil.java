package ch2.pertemuan1OOP.enumex;

public class Mobil {
    private  RODA roda;
    private  TYPEEX type;
    private  int kecepatan ;

}
