package ch2.pertemuan2OOP.kelas;

public class DTO {
}
