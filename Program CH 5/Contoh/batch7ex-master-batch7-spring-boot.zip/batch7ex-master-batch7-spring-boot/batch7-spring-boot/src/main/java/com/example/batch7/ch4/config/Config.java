package com.example.batch7.ch4.config;

import org.springframework.stereotype.Component;

@Component
public class Config {

    public  static String APP_NAME ="name";

    public static  String yourName(){
        return "riki";
    }
}
